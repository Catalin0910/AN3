# Subiect 4
# Topic: REACT

# Avand urmatoarea aplicatie create folosind modulul `create-react-app` completati urmatoarele cerinte:
- Adaugati componenta `AddDevice` in template-ul componentei `DeviceList`;
- Componenta `AddDevice` trebuie sa contina 2 elemente de tip `input` cu `id`: `name` si `price`;
- Componenta `AddDevice` trebuie sa contina un element de tip `button` cu textul `Submit`, folosit pentru a apela metoda `addItem`;
- Componenta `AddDevice` din interiorul componentei `DeviceList` trebuie sa contina o proprietate numita `onAdd` in obiectul `props`;
- La apasarea butonului `Submit` un nou element va fi afisat si adaugat in starea componentei `DeviceList`;

### INFORMATII UTILE: Obiectele adaugate in vectorul din starea componentei `DeviceList` sunt de forma { name: String, price: Number }.